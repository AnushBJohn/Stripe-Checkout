const express = require('express');
const router = express.Router();
const Stripe = require('stripe');
const Order = require('../models/Order');
require('dotenv').config();

const stripe = Stripe(process.env.STRIPE_SECRET_KEY);

router.post('/create-checkout-session', async (req, res) => {
  try {
    const { cart, email } = req.body;

    if (!email || !cart || cart.length === 0) {
      return res.status(400).json({ error: 'Email and cart items are required.' });
    }

    const lineItems = cart.map(item => ({
      price_data: {
        currency: 'inr',
        product_data: {
          name: item.name
        },
        unit_amount: item.price * 100
      },
      quantity: 1
    }));

    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      line_items: lineItems,
      mode: 'payment',
      customer_email: email,
      success_url: 'http://localhost:5500/frontend/success.html',
      cancel_url: 'http://localhost:5500/frontend/failure.html',
      metadata: { email }
    });

    const newOrder = new Order({
      email,
      items: cart,
      status: 'pending',
      sessionId: session.id
    });

    await newOrder.save();

    res.json({ url: session.url });
  } catch (err) {
    console.error('Error creating checkout session:', err.message);
    res.status(500).json({ error: 'Failed to create Stripe session.' });
  }
});

router.post('/webhook', express.raw({ type: 'application/json' }), async (req, res) => {
  const endpointSecret = process.env.STRIPE_WEBHOOK_SECRET;
  const sig = req.headers['stripe-signature'];

  let event;

  try {
    event = stripe.webhooks.constructEvent(req.body, sig, endpointSecret);
  } catch (err) {
    console.error('Webhook Error:', err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  const session = event.data.object;

  if (event.type === 'checkout.session.completed') {
    try {
      await Order.findOneAndUpdate(
        { sessionId: session.id },
        {
          status: 'success',
          transactionId: session.payment_intent
        }
      );
      console.log('Order marked as success');
    } catch (err) {
      console.error('Failed to update order status:', err.message);
    }
  }

  if (event.type === 'checkout.session.async_payment_failed') {
    try {
      await Order.findOneAndUpdate(
        { sessionId: session.id },
        {
          status: 'failed',
          transactionId: session.payment_intent
        }
      );
      console.log('⚠️ Order marked as failed');
    } catch (err) {
      console.error('Failed to mark order as failed:', err.message);
    }
  }

  res.status(200).json({ received: true });
});

module.exports = router;
