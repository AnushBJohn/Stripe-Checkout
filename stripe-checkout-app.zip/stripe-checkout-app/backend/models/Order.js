const mongoose = require('mongoose');

const orderSchema = new mongoose.Schema({
  email: String,
  items: Array,
  status: { type: String, default: 'pending' },
  sessionId: String,
  transactionId: String,  
}, { timestamps: true });

module.exports = mongoose.model('Order', orderSchema);

