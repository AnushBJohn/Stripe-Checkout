const products = [
  { id: 1, name: 'T-shirt', price: 499 },
  { id: 2, name: 'Cap', price: 199 },
  { id: 3, name: 'Mug', price: 299 }
];


if (document.getElementById('product-list')) {
  const container = document.getElementById('product-list');
  products.forEach(product => {
    const div = document.createElement('div');
    div.innerHTML = `
      <p>${product.name} - ₹${product.price}</p>
      <button onclick="addToCart(${product.id})">Add to Cart</button>
    `;
    container.appendChild(div);
  });
}

function addToCart(id) {
  const cart = JSON.parse(localStorage.getItem('cart')) || [];
  const item = products.find(p => p.id === id);
  cart.push(item);
  localStorage.setItem('cart', JSON.stringify(cart));
  updateCartCount();
}

function updateCartCount() {
  const cart = JSON.parse(localStorage.getItem('cart')) || [];
  const countElem = document.getElementById('cart-count');
  if (countElem) countElem.textContent = cart.length;
}

if (document.getElementById('cart-items')) {
  const cart = JSON.parse(localStorage.getItem('cart')) || [];
  const container = document.getElementById('cart-items');
  cart.forEach(item => {
    const div = document.createElement('div');
    div.innerHTML = `<p>${item.name} - ₹${item.price}</p>`;
    container.appendChild(div);
  });
}

async function checkout() {
  const cart = JSON.parse(localStorage.getItem('cart')) || [];
  const email = document.getElementById('email').value;

  if (!email) {
    alert('Email is required');
    return;
  }

  const response = await fetch('http://localhost:5000/api/stripe/create-checkout-session', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ cart, email })
  });

  const data = await response.json();
  if (data.url) {
    window.location.href = data.url;
  } else {
    alert('Error creating checkout session');
  }
}


updateCartCount();
